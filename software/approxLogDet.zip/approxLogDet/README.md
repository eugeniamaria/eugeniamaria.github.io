# Overview

This software implements the ideas described in the paper: [`A Randomized Algorithm for Approximating the Log Determinant of a Symmetric Positive Definite Matrix`](https://arxiv.org/abs/1503.00374).

This software contains high-quality, shared-memory and distributed-memory parallel C++ code for the algorithms listed in the above paper. In it’s current state, it supports: (1) ingesting dense (binary and text format) and sparse (binary, text, and matrix market format) matrices, (2) generating large random SPD matrices, (3) computing both approximate and exact spectral norms of matrices, (4) computing both approximate and exact traces of matrices, and (5) computing both approximate and exact log determinants of matrices.

It supports both [Eigen](eigen.tuxfamily.org) and [Elemental](https://github.com/elemental/Elemental) matrices. At the time of developing this software, `Eigen` supported both dense and sparse matrices, while `Elemental` supported dense matrices and only recently added support for sparse matrices (pre-release). As it is preferable that the random SPD generation is fast, parallel random number generators from `Random123` are used in conjunction with `Boost.Random`.

# Briefly...

All of the novelty in the aforementioned paper is contained in three files in the code:

* `trace.hpp`, particularly the `apply()` function.
* `spectral_norm.hpp`, particularly the `apply()` function.
* `logdet.hpp`, particularly the `apply()` function.

**Everything else is boilerplate.**

# Software Dependencies

This package explicitly depends on `C++`, `python 2.7`, `Elemental`, `Eigen`, `OpenMPI`, and `Boost`. It also uses `Random123` along with `Boost.Random`. It worked accurately and with good performance with the following versions: Latest version of `Elemental` from `GitHub`, `Eigen 3.2.4`, `OpenMPI 1.8.4`, `Boost 1.55.7`, and finally `GCC` version `4.9.2`. CMake (minimum version `2.8`) was used to build the system. **If** you need to ingest matrix market format, you also need to compile the freely available `mmio.h` and `mmio.c` into a library called `libmmio`. See `CMake/FindMatrixMarket` for additional details (and files in the `external` folder).

# Code statistics

* 22 total files, approximately 3500 lines of code.
* 7 `CMake` build files for the build system: 520 lines of code.
* 3 *key* files that contain algorithms from the paper: 924 lines of code.
  * Present in the `ALD` folder.
  * `trace.hpp`, `spectral_norm.hpp`, `logdet.hpp`
* 7 boilerplate files for reading, logging, timing, etc: 1000 lines of code.
  * Present in the `ALD` folder.
  * `{log,load,matrix_market,matrix_visitor,random_matrices,timer,utility}.hpp`
* 5 *harness* files/scripts to run experiments.
  * Present in the `tests` folder: 900 lines of code.
  * `{harness_Elemental,harness_Eigen}.cpp`, `options.cpp`.
  * `run_tests.py` and `matrices_ufl.lst`

# Code Organization

## Build system

`CMake` (minimum version `2.8`) is used to build all the code listed in this paper. The specific `Find*` and the various `CMakeLists.txt` files here are adaptations of other such files that have been written or seen others write for other open-source projects.

## `ALD`

This directory contains the crux of the implementation of the algorithms in the paper. In essence, there are three stages in the processing pipeline for the code.

### Input: generating random matrices or reading them from files

The first step is the processing ingesting or generating a (symmetric positive definite) matrix from somewhere: generation of random dense and sparse matrices are supported - reading in text and binary (symmetric positive definite) matrices for both `Elemental` and `Eigen` packages.

#### Files

* `random_matrices.hpp`
  * Generates dense (`Eigen` and `Elemental`) and sparse (`Eigen`) random PSD.
  * The implementations are contained in the `apply()` method.
  * Idea for `apply_becker()` method for `Elemental` is from Stephen Becker.
* `matrix_market.hpp`
  * Reads a sparse matrix in [Matrix Market](math.nist.gov/MatrixMarket).
  * Popular (and freely available) sparse matrix format.
  * Used in `load.hpp` below.
* `load.hpp`
  * `Eigen` Matrices
    * `load_sparse()` reads and loads `ijv` or `matrix_market` files from text.
    * `load_dense()` reads either
  * `Elemental` Matrices
    * The code as for `Eigen` matrices to load text or bin matrices locally.
    * Distribution of local matrices globally follows from Jack Poulson.

### Computing and approximate trace, norm, and logdet

**These three files contain all the novelty in the paper/code**

The crux of this paper is to accurately and efficiently approximate the log of the determinant of a symmetric positive definite matrix. In order to claim that this approximation is both correct(-ish) and of low latency, exact and approximate versions for both sparse and dense matrices were implemented. In the case of the exact version of the sparse matrices, Cholesky factorization was used for reasons explained in Section 5 (Experiments) of the paper.

#### Files

* `trace.hpp`
* `spectral_norm.hpp`
* `logdet.hpp`
* Common themes in these files are:
    * The computations are enabled for both `Elemental` and `Eigen` matrices.
    * `apply()` method approximates a value (say `trace` or `spectral norm`).
    * `check()` method computes the same value exactly.
    * `apply()` methods are nearly ported over from pseudo-code in the paper.

### Utility files

These are files that support utility operations such as logging, timing, and abstracting away the different matrix interfaces of `Eigen` and `Elemental` in the rest of the code base.

#### Files

* `log.hpp`
  * Simple `Boost` logging that enables some debug and trace-level printing.
* `matrix_visitor.hpp`
  * Uniform way of accessing both `Eigen` and `Elemental` matrices.
  * Inspired by `Boost` library.
* `timer.hpp`
  * A few lines of code to compute elapsed time.
* `utility.hpp`
  * Generates a random seed.

## `tests`

This folder contains the `main()` functions and scripts to run the experiments in the paper.

### Files

* `options.hpp`
  * Just a command line parser.
  * Uses `Boost.program_options`, which is equivalent of `Python.Argparse`.
* `harness_Elemental.cpp`
  * Contains the `main()` for the `Elemental` program's execution.
  * Read command line options, read matrices, compute `trace()`...`logdet()`
* `harness_Eigen.cpp`
  * Contains the `main()` for the `Eigen` program's execution.
  * Read command line options, read matrices, compute `trace()`...`logdet()`
* `run_tests.py`
  * Script to run the experiments.
  * This script was used to generate all the graphs in the paper.

## `CMake`

This directory contains three files to check for required software dependencies that do not come pre-packaged with `CMake`.

### Files

* `FindElemental.cmake`
  * Checks for presence of `Elemental`.
* `FindEigen3.cmake`
  * **This is provided by authors of `Eigen` on the internet**
  * Checks for presence of `Eigen3`
* `FindMatrixMarket.cmake`
  * Checks for `mmio.h` and `mmio.c`.
