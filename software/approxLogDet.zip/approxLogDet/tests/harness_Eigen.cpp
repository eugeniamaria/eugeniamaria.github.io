#include <iostream>
#include <fstream>
#include <functional>
#include <cstring>
#include <vector>
#include <utility>
#include <cstdio>
#include <map>

#include <Eigen/Dense>
#include <Eigen/Sparse>

#ifdef OPENMP
# include <omp.h>
#endif

#include <ALD/log.hpp>
#include <ALD/logdet.hpp>
#include <ALD/timer.hpp>
#include <ALD/load.hpp>
#include <ALD/random_matrices.hpp>
#include <ALD/spectral_norm.hpp>
#include <ALD/trace.hpp>

#include "options.hpp"

/** Create somconvenient typedefs */
typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> DenseMatrixType;
typedef boost::shared_ptr<DenseMatrixType> DenseMatrixPtrType;

typedef Eigen::SparseMatrix<double> SparseMatrixType;
typedef boost::shared_ptr<SparseMatrixType> SparseMatrixPtrType;
typedef Eigen::Triplet<double> IJVTripletType;

template <typename MatrixType>
int process (options_t& program_opts,
             boost::shared_ptr<MatrixType> A) {
  ALD::timer_t duration;
  spectral_norm_t<MatrixType> spectral_norm (program_opts.n, program_opts.t);
  double lambda_1_accura = 0.0;
  ALD::timer_t::value_type lambda_1_accura_time;
  if (program_opts.exact_l2_norm) {
    lambda_1_accura = spectral_norm.check(A);
    lambda_1_accura_time = duration.toc();
    duration.tic();
  }
  const double lambda_1_approx = spectral_norm.apply(A);
  const ALD::timer_t::value_type lambda_1_approx_time = duration.toc();
  std::cout << "Spectral norm (true=" << lambda_1_accura << ","
                               << lambda_1_approx << ")"
                               << " in "
                               << "(true=" << lambda_1_accura_time << ","
                               << lambda_1_approx_time << ")" << std::endl;

  /***********************************************************************/

  trace_t<MatrixType> approx_trace (program_opts.n, program_opts.p);
  duration.tic();
  double trace_accura = 0.0;
  ALD::timer_t::value_type trace_accura_time;
  if (program_opts.exact_trace) {
    trace_accura = approx_trace.check(A);
    trace_accura_time = duration.toc();
    duration.tic();
  }
  double trace_approx = approx_trace.apply(A);
  const ALD::timer_t::value_type trace_approx_time = duration.toc();
  std::cout << "Matrix trace (true=" << trace_accura << ","
                              << trace_approx << ")"
                               << " in "
                               << "(true=" << trace_accura_time << ","
                               << trace_approx_time << ")" << std::endl;

  /***********************************************************************/

  logdet_t<MatrixType> logdet(program_opts.n,
                              program_opts.t,
                              program_opts.p,
                              program_opts.m,
                              program_opts.alpha);
  duration.tic();
  double logdet_accura = 0.0;
  ALD::timer_t::value_type logdet_accura_time;
  if (program_opts.exact_logdet) {
    logdet_accura = logdet.check(A);
    logdet_accura_time = duration.toc();
    duration.tic();
  }
  const double logdet_approx = logdet.apply(A);
  const ALD::timer_t::value_type logdet_approx_time = duration.toc();
  std::cout << "Logdet (true=" << logdet_accura << ","
                        << logdet_approx << ")"
                        << " in "
                        << "(true=" << logdet_accura_time << ","
                        << logdet_approx_time << ")" << std::endl;

  /***********************************************************************/

  return 0;
}

template <typename MatrixType>
void run_benchmarks (const options_t& program_opts,
                     boost::shared_ptr<MatrixType> A) {
  // Create the logdet object
  logdet_t<MatrixType> logdet(program_opts.n,
                              program_opts.t,
                              program_opts.p,
                              program_opts.m,
                              program_opts.alpha);

  // Measure the time for the accurate logdet
  ALD::timer_t duration;
  const double logdet_accura = logdet.check(A);
  const ALD::timer_t::value_type logdet_accura_time = duration.toc();

  for (int64_t iter=0; iter<program_opts.maxIter; ++iter) {
    const int seed = generate_seed();
    for (int64_t m=1; m<=program_opts.maxM; m+=4) {
      // Create the logdet object
      logdet_t<MatrixType> logdet(program_opts.n,
                                  program_opts.t,
                                  program_opts.p,
                                  m,
                                  program_opts.alpha,
                                  seed);

      duration.tic();
      const double logdet_approx = logdet.apply(A);
      const ALD::timer_t::value_type logdet_approx_time = duration.toc();
      std::cout << std::left
                << std::setw(9)  << program_opts.n << " "
                << std::setw(3)  << m << " "
                << std::setw(3)  << program_opts.t << " "
                << std::setw(3)  << program_opts.p << " "
                << std::setw(12) << logdet_approx << " "
                << std::setw(12) << logdet_accura << " "
                << std::setw(10) << logdet_approx_time << " "
                << std::setw(10) << logdet_accura_time
                << std::endl;
    }
  }
}

int main (int argc, char** argv) {
  /***********************************************************************/

  /* parse everything */
  options_t program_opts (argc, argv, true/**this is the root*/);
  if (program_opts.exit_on_return) { return -1; }
  if (1<program_opts.verbosity) program_opts.pretty_print(/**always root*/true);

  /***********************************************************************/

  /** Set the logger verbosity */
  setLogLevel(program_opts.verbosity);

  /***********************************************************************/

  /** Initialize eigen parallelism */
  Eigen::initParallel();

  /***********************************************************************/

  /** Do all the processing in functions that are specific sparsity */
  if (0<program_opts.nnz ||
      program_opts.input_fileformat.find("SPARSE") != std::string::npos) {
    /** Get the matrices one way or the other */
    SparseMatrixPtrType A;
    if (program_opts.use_random) {
      LOG_DEBUG << "Using a random matrix for the experiment";
      A = rand_psd_t<SparseMatrixType>::apply(program_opts.n, /** dimension=nxn */
                                              program_opts.nnz); /** sparsity */
    } else {
      LOG_DEBUG << "Using a sparse matrix for the experiment";
      A = load_sparse (program_opts.input_filename,
                       program_opts.input_fileformat,
                       program_opts.n,
                       program_opts.nnz);
    }

    if (program_opts.gen_and_dump) std::cout << *A;
    else if (program_opts.benchmark) run_benchmarks (program_opts, A);
    else process (program_opts, A);

  } else {
    /** Get the matrices one way or the other */
    DenseMatrixPtrType A;
    if (program_opts.use_random) {
      LOG_DEBUG << "Using a random matrix for the experiment";
      A = rand_psd_t<DenseMatrixType>::apply(program_opts.n);/** dimension=nxn */
    } else {
      LOG_DEBUG << "Using a dense matrix for the experiment";
      A = load_dense (program_opts.input_filename,
                      program_opts.input_fileformat,
                      program_opts.n);
    }

    if (program_opts.gen_and_dump) std::cout << *A;
    else if (program_opts.benchmark) run_benchmarks (program_opts, A);
    else process (program_opts, A);

  }

  /***********************************************************************/
}
