#ifndef LOAD_HPP
#define LOAD_HPP

#include <sys/stat.h>
#include <boost/shared_ptr.hpp>
#include <boost/tokenizer.hpp>
#include <boost/foreach.hpp>
#include <boost/lexical_cast.hpp>


#include "log.hpp"
#include "timer.hpp"

/* check if something is a directory */
static inline bool is_directory (const char* candidate) {
  struct stat s;
  return (0 == stat (candidate, &s) && (s.st_mode&S_IFDIR));
}

/* check if something is a file */
static inline bool is_file (const char* candidate) {
  struct stat s;
  return (0 == stat (candidate, &s) && (s.st_mode&S_IFREG));
}

/**
 * Read a sparse format (i,j,v)
 */
template <typename IndexOutputIterator,
          typename ValueOutputIterator>
void read_ascii_ijv (const std::string& input_filename,
                     IndexOutputIterator row_indices,
                     IndexOutputIterator col_indices,
                     ValueOutputIterator values) {
  typedef typename std::iterator_traits<IndexOutputIterator>::value_type
                                                                index_type;
  typedef typename std::iterator_traits<ValueOutputIterator>::value_type
                                                                value_type;
  ALD::timer_t duration;

  /** open the file */
  std::ifstream in (input_filename.c_str());
  if (false==in.is_open()) {
    LOG_TRACE << "Could not open " <<input_filename;
    return;
  }

  /** create a token separator */
  typedef boost::tokenizer<boost::char_separator<char> > tokenizer_type;
  boost::char_separator<char> separators(" ");

  /** iterate over all the lines and populate the buffer */
  std::string current_line;
  for (int64_t i=0; getline (in, current_line); ++i) {
    tokenizer_type tokens(current_line, separators);
    int64_t token_index = 0;
    for (tokenizer_type::iterator token_iter = tokens.begin();
         token_iter != tokens.end();
         ++token_iter, ++token_index) {
      switch (token_index) {
        case 0:
        *row_indices++ = boost::lexical_cast<index_type>(token_iter->c_str());
        break;

        case 1:
        *col_indices++ = boost::lexical_cast<index_type>(token_iter->c_str());
        break;

        case 2:
        *values++ = boost::lexical_cast<value_type>(token_iter->c_str());
        break;
      };
    }
  }

  /* close the file stream */
  in.close();
  LOG_TRACE << "Reading time = " << duration.toc();
}

/**
 * [values in double precision in column-major order]
 */
template <typename OutputIterator>
void read_ascii_dense (const std::string& input_filename,
                       OutputIterator result) {
  typedef typename std::iterator_traits<OutputIterator>::value_type value_type;
  ALD::timer_t duration;

  /** open the file */
  std::ifstream in (input_filename.c_str());
  if (false==in.is_open()) {
    LOG_ERROR << "Could not open " << input_filename;
    return;
  }

  /** create a token separator */
  typedef boost::tokenizer<boost::char_separator<char> > tokenizer_type;
  boost::char_separator<char> separators(" ");

  /** iterate over all the lines and populate the buffer */
  std::string current_line;
  for (int64_t i=0; getline (in, current_line); ++i) {
    tokenizer_type tokens(current_line, separators);
    for (tokenizer_type::iterator token_iter = tokens.begin();
         token_iter != tokens.end();
         ++token_iter) {
      *result++=boost::lexical_cast<value_type>(token_iter->c_str());
    }
  }

  /* close the file stream */
  in.close();
  LOG_TRACE << "Reading time = " << duration.toc();
}

/**
 * [values in double precision in column-major order]
 */
template <typename RandomAccessIterator>
void read_binary_dense (const std::string& input_filename,
                        int64_t n,
                        RandomAccessIterator values) {
  typedef typename std::iterator_traits<RandomAccessIterator>::value_type
                                                               value_type;

  ALD::timer_t duration;

  /* open the file */
  std::ifstream in (input_filename.c_str(), std::ios::binary);

  /* check for any obvious errors */
  if (false==in.is_open()) {
    LOG_ERROR << "Could not open " << input_filename;
    return;
  }

  /* Now, read the requested number of bytes */
  in.read (reinterpret_cast<char*>(&(values[0])),
           (sizeof(value_type)*(n*n)));

  /* close the file stream */
  in.close();

  LOG_TRACE << "Reading time = " << duration.toc();
}

#if ALD_HAVE_ELEMENTAL==1

#include <El.hpp>

/**
 * This function exists to load a dense matrix into memory. Make sure that the
 * file that is passed actually exists and contains the matrix in the following
 * format:
 *
 * At the end of the operation, the matrix is loaded in a Matrix<T>
 *
 * @param[in] file_name The file that we want to load
 * @param[in] n The dimension of the matrix
 * @return A shared pointer that has the required matrix
 */
static inline boost::shared_ptr<El::Matrix<double> >
load_dense_lcl (const std::string& input_filename,
                const std::string& input_fileformat,
                int64_t n,
                bool is_root) {

  /** 0. Declare the return value */
  boost::shared_ptr<El::Matrix<double> > A_lcl;

  if (is_root) {
    /* 2.1 Check for validity of arguments */
    if (false == is_file (input_filename.c_str())) {
      LOG_ERROR << input_filename << " is not a valid file";
      MPI_Abort (MPI_COMM_WORLD, 3);
      return A_lcl;
    }

    /* 2.2 File is valid, simply read in the matrix */
    A_lcl = boost::shared_ptr<El::Matrix<double> >
                   (new El::Matrix<double> (n, n));
    if ("DENSE_TXT" == input_fileformat) {
      read_ascii_dense (input_filename, A_lcl->Buffer());
    } else if ("DENSE_BIN" == input_fileformat) {
      read_binary_dense (input_filename, n, A_lcl->Buffer());
    }

    /* 2.3 Broadcast this to everyone */
    MPI_Bcast (A_lcl->Buffer(),
               n*n,
               MPI_DOUBLE,
               0,  /** this is a hack assuming root is 0 */
               MPI_COMM_WORLD);
  } else {
    /* 2.2 Allocate enough memory and get the values */
    A_lcl = boost::shared_ptr<El::Matrix<double> >
                   (new El::Matrix<double> (n, n));
    double* values = A_lcl->Buffer();
    MPI_Bcast (values,
               n*n,
               MPI_DOUBLE,
               0, /** this is a hack assuming root is 0 */
               MPI_COMM_WORLD);
  }

  return A_lcl;
}


/** A functor that assigns a local matrix to a distributed matrix */
struct global_assigner_t {
  typedef boost::shared_ptr<El::Matrix<double> > MatrixPtrType;
  typedef boost::shared_ptr<El::DistMatrix<double> > DistMatrixPtrType;

  MatrixPtrType A_lcl;

  global_assigner_t (MatrixPtrType A_lcl) : A_lcl(A_lcl) {}

  void apply (DistMatrixPtrType A,
              int64_t i,
              int64_t j,
              int64_t i_lcl,
              int64_t j_lcl) {
    A->SetLocal(i_lcl, j_lcl, A_lcl->Get(i,j));
  }
};

/**
 * This function exists to load a dense matrix into memory. Make sure that the
 * file that is passed actually exists and contains the matrix.
 *
 * @param[in] file_name The file that we want to load
 * @param[in] n The dimension of the matrix
 * @return A shared pointer that has the required matrix
 */
static inline boost::shared_ptr<El::DistMatrix<double> >
load_dense (const std::string& input_filename,
            const std::string& input_fileformat,
            int64_t n,
            bool is_root) {

  /** 0. Declare the return value */
  boost::shared_ptr<El::Matrix<double> > A_lcl;
  boost::shared_ptr<El::DistMatrix<double> > A;

  /* 1. Load this data and keep it in a Matrix<double> */
  LOG_TRACE << "Loading " << input_filename << " locally ";

  /* 2 Load the local matrix */
  ALD::timer_t duration;
  A_lcl = load_dense_lcl(input_filename, input_fileformat, n, is_root);
  LOG_TRACE << " DONE in " << duration.toc();

  if (A_lcl==NULL) return A;

  /* 3 Now, from the local matrices, make things global */
  A = boost::shared_ptr<El::DistMatrix<double> >
                 (new El::DistMatrix<double>(A_lcl->Height(),
                                             A_lcl->Width()));
  global_assigner_t global_assigner(A_lcl);
  matrix_visitor_t<El::DistMatrix<double>,
                   global_assigner_t>::apply(A, global_assigner);

  return A;
}

#endif /** ALD_HAVE_ELEMENTAL==1 */

#if ALD_HAVE_EIGEN==1

#include <Eigen/Dense>
#include <Eigen/Sparse>

#if ALD_HAVE_MATRIX_MARKET==1
#include "matrix_market.hpp"
#endif

/**
 * This function exists to load a dense matrix into memory. Make sure that the
 * file that is passed actually exists and contains the matrix in the following
 * format:
 *
 * At the end of the operation, the matrix is loaded in a
 * Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>
 *
 * @param[in] file_name The file that we want to load
 * @param[in] n The dimension of the matrix
 * @return A shared pointer that has the required matrix
 */
static inline boost::shared_ptr<Eigen::Matrix<double,
                                Eigen::Dynamic,
                                Eigen::Dynamic> >
load_dense (const std::string& input_filename,
            std::string& input_fileformat,
            int64_t n) {
  typedef Eigen::Matrix<double,
                        Eigen::Dynamic,
                        Eigen::Dynamic> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;

  /** 0. Declare the return value */
  MatrixPtrType A;

  /** 1. Check for validity of arguments */
  if (false == is_file (input_filename.c_str())) {
    LOG_ERROR << input_filename << " is not a valid file";
    return A;
  }

  /** 3. File is valid, simply read in the matrix */
  A = MatrixPtrType (new MatrixType(n,n));
  if ("DENSE_TXT" == input_fileformat) {
    read_ascii_dense (input_filename, A->data());
  } else if ("DENSE_BIN" == input_fileformat) {
    read_binary_dense (input_filename, n, A->data());
  }

  return A;
}

/**
 * This function exists to load a sparse matrix into memory. Make sure that the
 * file that is passed actually exists and contains the matrix in the following
 * format:
 *
 * At the end of the operation, the matrix is loaded in a
 * Eigen::SparseMatrix<double>
 *
 * @param[in] file_name The file that we want to load
 * @param[in] n The dimension of the matrix
 * @return A shared pointer that has the required matrix
 */
static inline boost::shared_ptr<Eigen::SparseMatrix<double> >
load_sparse (const std::string& input_filename,
             std::string& input_fileformat,
             int64_t n,
             int64_t nnz) {
  typedef Eigen::SparseMatrix<double> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;

  /** 0. Declare the return value */
  MatrixPtrType A;

  /** 1. Check for validity of arguments */
  if (false == is_file (input_filename.c_str())) {
    LOG_ERROR << input_filename << " is not a valid file";
    return A;
  }

  std::vector<Eigen::Triplet<double> > triplets(nnz);
  A = MatrixPtrType (new MatrixType(n,n));

  /** 3. File is valid, simply read in the matrix */
  if ("SPARSE_IJV" == input_fileformat) {
    std::vector<int64_t> row_indices(nnz);
    std::vector<int64_t> col_indices(nnz);
    std::vector<double> values(nnz);
    read_ascii_ijv (input_filename,
                    row_indices.begin(),
                    col_indices.begin(),
                    values.begin());
    for (int64_t i=0; i<nnz; ++i) {
      triplets.at(i) = Eigen::Triplet<double>(row_indices[i],
                                              col_indices[i],
                                              values[i]);
    }
  } else if ("SPARSE_MM" == input_fileformat) {
#if ALD_HAVE_MATRIX_MARKET==1
    std::pair<int,int> n_and_nnz =
       read_matrix_market (input_filename.c_str(),
                           true, /** is_symmetric */
                           triplets.begin());
#endif
  }

  A->setFromTriplets(triplets.begin(), triplets.end());
  A->makeCompressed();

  return A;
}

#endif /** ALD_HAVE_EIGEN==1 */

#endif /** LOAD_HPP */
