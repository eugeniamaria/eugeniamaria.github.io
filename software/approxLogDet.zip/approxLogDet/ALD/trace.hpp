#ifndef ALD_TRACE_HPP
#define ALD_TRACE_HPP


#include <ALD/config.h>
#include <boost/random.hpp>
#include <boost/random/threefry.hpp>
#include <boost/random/counter_based_engine.hpp>

#include "log.hpp"
#include "timer.hpp"
#include "utility.hpp"

/**
 * @brief Compute the approximate trace of matrix A. 
 * @param[in] A Symmetrix positive definite matrix.
 * @return Approximate trace of A
 */
template <typename MatrixType>
struct trace_t {
  /**
   * Constructor:
   * trace_t (int64_t n, int64_t p);
   */

  /**
   * Approximate the trace of a power.
   *
   * Note: The apply method has side-effects, i.e., it keeps a state of the input matrix for efficient computation
   * of the trace of all powers of A, i.e., A^2, A^3, ..., in increasing order.
   *
   * double apply (boost::shared_ptr<MatrixType>);
   */

  /**
   * Compute the trace of a power.
   * double check (boost::shared_ptr<MatrixType>, int64_t power);
   */
};

#if ALD_HAVE_ELEMENTAL==1

#include <mpi.h>
#include <El.hpp>

/** Specialization for Elemental matrices */
template <>
struct trace_t<El::DistMatrix<double> > {
  typedef El::DistMatrix<double> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;
  typedef boost::random::threefry<4, uint32_t> Prf;
  typedef boost::random::counter_based_engine<uint32_t, Prf, 64> engine_type;
  typedef boost::normal_distribution<double> nrm_real_type;
  typedef boost::variate_generator<engine_type,
                                   nrm_real_type> nrm_real_prng_type;

  struct make_normal_t {
    mutable nrm_real_prng_type prng;

    make_normal_t(int seed) : prng(engine_type(seed), nrm_real_type(0.,1.)) {}

    double operator()(double in) const { return prng(); }
  };

  int64_t n;
  int64_t p;
  MatrixPtrType G;
  MatrixPtrType V;
  MatrixPtrType V_shdw;
  MatrixPtrType g_j;
  MatrixPtrType v_j;

  /**
   * Constructor:
   * Initialize a matrix with A. Given this, you can initialize the set of
   * random vectors that are needed to compute successive traces.
   */
  trace_t (int64_t n,
           int64_t p,
           int seed=-1) : n(n),
                        p(p),
                        G(new MatrixType(n,p)),
                        V(new MatrixType(n,p)),
                        V_shdw(new MatrixType(n,p)),
                        g_j(new MatrixType(n,1)),
                        v_j(new MatrixType(n,1)) {
    ALD::timer_t duration;
    LOG_DEBUG << "Creating G and setting V=G";
    if (0>seed) seed = generate_seed();
    El::EntrywiseMap(*G, std::function<double(double)>(make_normal_t(seed)));
    El::Copy (*G, *V);
    LOG_DEBUG << "DONE in " << duration.toc();
  }

  /**
   * Compute the trace of the matrix given the current state.
   */
  double apply(MatrixPtrType A) {
    /** 1. Compute AV first */
    ALD::timer_t duration;
    LOG_DEBUG << "Computing AV ";

    El::Hemm(El::LEFT, El::UPPER, 1.0, *A, *V, 0.0, *V_shdw);
    V.swap (V_shdw);

    LOG_DEBUG << "DONE in " << duration.toc();

    /** 1.5 Should we orthonormalize the Gaussians in the middle? */

    /** 2. Compute (g^T)Av for each g, v next */
    duration.tic();
    LOG_DEBUG << "Computing G^TAV ";

    double approx_trace = 0.0;
    for (int64_t j=0; j<p; ++j) {
      /** Create locked views to the matrix */
      El::LockedView(*g_j, *G, 0, j, n, 1);
      El::LockedView(*v_j, *V, 0, j, n, 1);

      /** Compute the dot product */
      approx_trace += El::Dot(*g_j, *v_j);
    }

    /** Divide by the number of Gaussians you are using */
    approx_trace /= p;

    LOG_DEBUG << "DONE in " << duration.toc();

    return approx_trace;
  }

  double check (MatrixPtrType A, int64_t power=1) {
    ALD::timer_t duration;
    LOG_DEBUG << "Computing A^(power) ";

    MatrixPtrType A_pow =
                 MatrixPtrType(new MatrixType(*A));
    MatrixPtrType A_pow_shdw =
                 MatrixPtrType(new MatrixType(*A));
    for (int64_t i=1; i<power; ++i) {
      El::Hemm(El::LEFT, El::UPPER, 1.0, *A_pow, *A, 0.0, *A_pow_shdw);
      A_pow.swap(A_pow_shdw);
    }

    LOG_DEBUG << "DONE in " << duration.toc();

    duration.tic();
    LOG_DEBUG << "Computing trace_lcl(A^(power)) ";

    MatrixType D(n, 1);
    El::GetDiagonal (*A_pow, D);
    const int64_t i_max = D.LocalHeight();
    double trace_lcl = 0.0;
    if (D.LocalWidth()) {
      for(int64_t i_lcl=0; i_lcl<i_max; ++i_lcl) trace_lcl+=D.GetLocal(i_lcl, 0);
    }

    LOG_DEBUG << "DONE in " << duration.toc();

    /** Get the values from everywhere */
    double trace_gbl;
    duration.tic();
    LOG_DEBUG << "Summing up to get global trace(A^(power)) ";

    MPI_Allreduce (&trace_lcl,
                   &trace_gbl,
                   1,
                   MPI_DOUBLE,
                   MPI_SUM,
                   A_pow->DistComm().comm);

    LOG_DEBUG << "DONE in " << duration.toc();

    return trace_gbl;
  }
};

#endif /** ALD_HAVE_ELEMENTAL */

#if ALD_HAVE_EIGEN==1

#include <Eigen/Dense>

/** Implementation for Eigen Matrices */
template <typename EigenMT>
struct eigen_trace_t {
  typedef EigenMT EigenMatrixType;
  typedef Eigen::Matrix<double,
                        Eigen::Dynamic,
                        Eigen::Dynamic> DenseMatrixType;
  typedef boost::shared_ptr<EigenMatrixType> EigenMatrixPtrType;
  typedef boost::random::threefry<4, uint32_t> Prf;
  typedef boost::random::counter_based_engine<uint32_t, Prf, 64> engine_type;
  typedef boost::normal_distribution<double> nrm_real_type;
  typedef boost::variate_generator<engine_type,
                                   nrm_real_type> nrm_real_prng_type;

  int64_t n;
  int64_t p;
  DenseMatrixType G;
  DenseMatrixType V;

  /**
   * Constructor:
   * Initialize a matrix with A. Given this, you can initialize the set of
   * random vectors that are needed to compute successive traces.
   */
  eigen_trace_t (int64_t n,
                 int64_t p,
                 int seed) : n(n), p(p), G(n,p), V(n,p) {
    ALD::timer_t duration;
    LOG_DEBUG << "Creating G and setting V=G";
    if (0>seed) seed = generate_seed();
    nrm_real_prng_type prng (engine_type(generate_seed()),
                             (nrm_real_type(0., 1.)));
    for(int64_t j=0;j<G.cols();++j)
        for(int64_t i=0;i<G.rows();++i)
            G(i,j)=prng();
    V = G;
  }

  /**
   * Compute the trace of the matrix given the current state.
   */
  double apply(EigenMatrixPtrType A) {
    /** 1. Compute AV first */
    ALD::timer_t duration;
    LOG_DEBUG << "Computing AV ";
    V = (*A) * V;
    LOG_DEBUG << "DONE in " << duration.toc();

    /** 1.5 Should we orthonormalize the Gaussians in the middle? */

    /** 2. Compute (g^T)Av for each g, v next */
    duration.tic();
    LOG_DEBUG << "Computing G^TAV ";

    /** Eigen stores things in column-major order --- OK to do it by hand */
    double approx_trace = 0.0;
    for(int64_t j=0;j<p;++j)
        for(int64_t i=0;i<n;++i)
            approx_trace+=G(i,j)*V(i,j);

    /** Divide by the number of Gaussians you are using */
    approx_trace /= p;

    LOG_DEBUG << "DONE in " << duration.toc();

    return approx_trace;
  }

  double check (EigenMatrixPtrType A, int64_t power=1) {
    ALD::timer_t duration;
    LOG_DEBUG << "Computing A^(power) ";

    EigenMatrixType A_pow = EigenMatrixType(*A);
    for (int64_t i=1; i<power; ++i) A_pow = A_pow*A_pow;

    LOG_DEBUG << "DONE in " << duration.toc();

    duration.tic();
    LOG_DEBUG << "Computing trace(A^(power)) ";

    double trace = 0.0;
    for (int64_t i=0;i<A_pow.diagonal().rows();++i)trace+=A_pow.diagonal()[i];

    LOG_DEBUG << "DONE in " << duration.toc();

    return trace;
  }
};

/** Specialization for Elemental matrices */
template <>
struct trace_t<Eigen::Matrix<double,
                             Eigen::Dynamic,
                             Eigen::Dynamic> > :
        public eigen_trace_t<Eigen::Matrix<double,
                             Eigen::Dynamic,
                             Eigen::Dynamic> > {
  typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> MatrixType;
  typedef eigen_trace_t<MatrixType> base_type;

  /**
   * Constructor:
   * Initialize a matrix with A. Given this, you can initialize the set of
   * random vectors that are needed to compute successive traces.
   */
  trace_t (int64_t n,
           int64_t p,
           int seed=-1) : base_type(n,p,seed) {}
};

/** Specialization for sparse Eigen matrices */
template <>
struct trace_t<Eigen::SparseMatrix<double> >:
        public eigen_trace_t<Eigen::SparseMatrix<double> > {
  typedef Eigen::SparseMatrix<double> MatrixType;
  typedef eigen_trace_t<MatrixType> base_type;

  /**
   * Constructor:
   * Initialize a matrix with A. Given this, you can initialize the set of
   * random vectors that are needed to compute successive traces.
   */
  trace_t (int64_t n,
           int64_t p,
           int seed=-1) : base_type(n,p,seed) {}
};

#endif /** ALD_HAVE_EIGEN */

#endif /** ALD_TRACE_HPP */
