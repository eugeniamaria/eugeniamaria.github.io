#ifndef ALD_TIMER_HPP
#define ALD_TIMER_HPP

#include <boost/date_time/posix_time/posix_time.hpp>

namespace ALD {

struct timer_t {
  typedef boost::posix_time::time_duration value_type;
  boost::posix_time::ptime start_time;

  timer_t () {
    tic();
  }

  void tic() {
    start_time = boost::posix_time::microsec_clock::local_time();
  }

  value_type toc() const {
    return boost::posix_time::microsec_clock::local_time()-start_time;
  }
};

} // namespace ALD

#endif /** ALD_TIMER_HPP */
