#ifndef LOGDET_HPP
#define LOGDET_HPP

#include <ALD/config.h>
#include <boost/shared_ptr.hpp>

#include "log.hpp"
#include "timer.hpp"
#include "spectral_norm.hpp"
#include "trace.hpp"
#include "utility.hpp"

/**
 * @brief Compute the approximate logdet of a matrix A.
 * @param[out] A Symmetrix positive definite matrix.
 * @return logdet of A
 */
template <typename MatrixType>
struct logdet_t {
  /**
   * define constructor as follows:
   * logdet_t (int64_t n,
   *           int64_t t,
   *           int64_t p,
   *           int64_t m,
   *           double alpha_ratio);
   */

  /* double apply (boost::shared_ptr<MatrixType>); */

  /* double check (boost::shared_ptr<MatrixType>); */
};

/**
 * This is base class that contains the common elements that are needed by
 * any specialization for approximating logdet of a matrix.
 */
template <typename MatrixType>
struct logdet_base_t {
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;
  typedef spectral_norm_t<MatrixType> SpectralNormType;
  typedef trace_t<MatrixType> TraceType;

  int64_t n;
  int64_t t;
  int64_t p;
  int64_t m;
  double alpha_ratio;
  MatrixPtrType C;
  SpectralNormType spectral_norm;
  TraceType trace;

  logdet_base_t (int64_t n,
                 int64_t t,
                 int64_t p,
                 int64_t m,
                 double alpha_ratio,
                 int seed) :  n(n),
                                        t(t),
                                        p(p),
                                        m(m),
                                        alpha_ratio(alpha_ratio),
                                        C (MatrixPtrType(new MatrixType(n,n))),
                                        spectral_norm(n,t,seed),
                                        trace(n,p,seed) { }
};

#if ALD_HAVE_ELEMENTAL==1

#include <mpi.h>
#include <El.hpp>

/** Specialization for Elemental */
template <>
struct logdet_t<El::DistMatrix<double> >
          : public logdet_base_t<El::DistMatrix<double> > {
  typedef El::DistMatrix<double> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;
  typedef logdet_base_t<MatrixType> LogDetBaseType;

  logdet_t (int64_t n,
            int64_t t,
            int64_t p,
            int64_t m,
            double alpha_ratio,
            int seed=-1) : LogDetBaseType(n,t,p,m,alpha_ratio,seed) {}

  double apply (MatrixPtrType A) {
    /** 1. Approximate the spectral norm of A */
    ALD::timer_t duration;
    LOG_DEBUG << "Approximating spectral norm of A ";
    const double lambda_1 = spectral_norm.apply (A);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** 2. Select "alpha" to be lambda_1 and 2*lambda_1 */
    const double alpha = alpha_ratio*lambda_1;

    /** 3. Set C = I - A/alpha */
    duration.tic();
    LOG_DEBUG << "Computing C = I - (A/alpha) ";
    El::Copy(*A, *C);
    El::Scale(1./alpha, *C);
    MatrixType D(n,1);
    El::GetDiagonal(*C, D);
    const int64_t i_max = D.LocalHeight();
    if (D.LocalWidth())
      for(int64_t i_lcl=0; i_lcl<i_max; ++i_lcl)
        D.SetLocal(i_lcl, 0, 1-D.GetLocal(i_lcl, 0));
    El::SetDiagonal(*C, D);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** 4. Approximate m terms of the Taylor series */
    duration.tic();
    LOG_DEBUG << "Approximating Taylor series of trace(A^k) ";
    double sum_of_traces = 0.0;
    for (int64_t k=1; k<=m; ++k) sum_of_traces+=(trace.apply (C) / k);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** 5. Return nlog(alpha) - avg(sum_of_traces) */
    double logdet_approx = n*log(alpha) - sum_of_traces;

    return logdet_approx;
  }

  double check (MatrixPtrType A) {
    /** First, create a copy because we want to preserve A */
    ALD::timer_t duration;
    LOG_DEBUG << "Copying A ";
    MatrixPtrType A_shdw = MatrixPtrType(new MatrixType(*A));
    LOG_DEBUG << "DONE in " << duration.toc();

    /** We compute the logdet by first computing the Cholesky factorization */
    duration.tic();
    LOG_DEBUG << "Computing Cholesky of A ";
    El::Cholesky(El::UPPER, *A_shdw);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** Pick the local diagonal entries by going through the local matrix */
    duration.tic();
    LOG_DEBUG << "Computing local determinant of A ";

    MatrixType D(n, 1);
    El::GetDiagonal (*A_shdw, D);
    const int64_t i_max = D.LocalHeight();
    double log_trace_lcl = 0.0;
    if (D.LocalWidth()) {
      for(int64_t i_lcl=0; i_lcl<i_max; ++i_lcl) {
        log_trace_lcl += log(D.GetLocal(i_lcl, 0));
      }
    }

    LOG_DEBUG << "DONE in " << duration.toc();
    duration.tic();
    LOG_DEBUG << "Computing global determinant of A ";

    double log_trace_gbl = 0;
    MPI_Allreduce (&log_trace_lcl,
                   &log_trace_gbl,
                   1,
                   MPI_DOUBLE,
                   MPI_SUM,
                   A_shdw->DistComm().comm);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** Multiply by 2 coz A = L'L */
    log_trace_gbl *= 2.0;

    return log_trace_gbl;
  }
};
#endif /** ALD_HAVE_ELEMENTAL==1 */

#if ALD_HAVE_EIGEN==1

#include <Eigen/Dense>
#include <Eigen/Sparse>

/** A structure that helps us figure out which Cholesky to use */
template <typename MatrixType> struct eigen_llt_t {};

/** Use Eigen::LLT for dense matrices */
template <>
struct eigen_llt_t <Eigen::Matrix<double,
                                  Eigen::Dynamic,
                                  Eigen::Dynamic> > {
  typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> MatrixType;
  typedef Eigen::LLT<MatrixType> LLTType;
};

/** Use Eigen::SimplicialLLT for sparse matrices */
template <>
struct eigen_llt_t <Eigen::SparseMatrix<double> > {
  typedef Eigen::SparseMatrix<double> MatrixType;
  typedef Eigen::SimplicialLLT<MatrixType> LLTType;
};

/** Specialization for Eigen matrices */
template <typename EigenMT>
struct eigen_logdet_t : public logdet_base_t<EigenMT> {
  typedef EigenMT EigenMatrixType;
  typedef boost::shared_ptr<EigenMatrixType> EigenMatrixPtrType;
  typedef logdet_base_t<EigenMatrixType> LogDetBaseType;

  eigen_logdet_t (int64_t n,
                  int64_t t,
                  int64_t p,
                  int64_t m,
                  double alpha_ratio,
                  int seed) : LogDetBaseType(n,t,p,m,alpha_ratio,seed) {}

  double apply (EigenMatrixPtrType A) {
    /** 0. Create an identity matrix, we need this */
    EigenMatrixType I = EigenMatrixType(A->rows(), A->cols());
    I.setIdentity();

    /** 1. Approximate the spectral norm of A */
    ALD::timer_t duration;
    LOG_DEBUG << "Approximating spectral nrm(A)..";
    const double lambda_1 = LogDetBaseType::spectral_norm.apply (A);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** 2. Select "alpha" to be lambda_1 and 2*lambda_1 */
    const double alpha = LogDetBaseType::alpha_ratio*lambda_1;

    /** 3. Set C = I - A/alpha */
    duration.tic();
    LOG_DEBUG << "Computing C=I-(A/alpha) ";
    (*LogDetBaseType::C) = I + (*A) * (-1.0/alpha);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** 4. Approximate m terms of the Taylor series */
    duration.tic();
    LOG_DEBUG << "Approximating Taylor series of trace(A^k) ";
    double sum_of_traces = 0.0;
    for (int64_t k=1; k<=LogDetBaseType::m; ++k) {
      sum_of_traces += (LogDetBaseType::trace.apply (LogDetBaseType::C)/k);
    }
    LOG_DEBUG << "DONE in " << duration.toc();

    /** 5. Return nlog(alpha) - avg(sum_of_traces) */
    double logdet_approx = LogDetBaseType::n*log(alpha) - sum_of_traces;

    return logdet_approx;
  }

  double check (EigenMatrixPtrType A) {
    /** First, create a copy because we want to preserve A */
    ALD::timer_t duration;
    LOG_DEBUG << "Copying A ";
    EigenMatrixType A_shdw = EigenMatrixType(*A);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** We compute the logdet by first computing the Cholesky factorization */
    duration.tic();
    LOG_DEBUG << "Computing Cholesky of A ";
    typename eigen_llt_t<EigenMatrixType>::LLTType cholesky_A_shdw(A_shdw);
    A_shdw = cholesky_A_shdw.matrixL();
    LOG_DEBUG << "DONE in " << duration.toc();

    /** Pick the local diagonal entries by going through the local matrix */
    duration.tic();
    LOG_DEBUG << "Computing local determinant of A ";

    double log_trace = 0.0;
    for (int64_t i=0; i<LogDetBaseType::n; ++i)
                  log_trace += log(A_shdw.diagonal()[i]);

    LOG_DEBUG << "DONE in " << duration.toc();

    /** Multiply by 2 coz A = L'L */
    log_trace *= 2.0;

    return log_trace;
  }
};

/** Specialization for Dense Eigen */
template <>
struct logdet_t<Eigen::Matrix<double,
                              Eigen::Dynamic,
                              Eigen::Dynamic> >
          : public eigen_logdet_t<Eigen::Matrix<double,
                                  Eigen::Dynamic,
                                  Eigen::Dynamic> > {
  typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;
  typedef eigen_logdet_t<MatrixType> LogDetBaseType;

  logdet_t (int64_t n,
            int64_t t,
            int64_t p,
            int64_t m,
            double alpha_ratio,
            int seed=-1) : LogDetBaseType(n,t,p,m,alpha_ratio,seed) {}
};

/** Specialization for Sparse Eigen */
template <>
struct logdet_t<Eigen::SparseMatrix<double> >
          : public eigen_logdet_t<Eigen::SparseMatrix<double> > {
  typedef Eigen::SparseMatrix<double> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;
  typedef eigen_logdet_t<MatrixType> LogDetBaseType;

  logdet_t (int64_t n,
            int64_t t,
            int64_t p,
            int64_t m,
            double alpha_ratio,
            int seed=-1) : LogDetBaseType(n,t,p,m,alpha_ratio,seed) {}
};

#endif /** ALD_HAVE_EIGEN==1 */

#endif /** LOGDET_HPP */
