#ifndef ALD_MATRIX_VISITOR_HPP
#define ALD_MATRIX_VISITOR_HPP

#include <ALD/config.h>
#include <boost/shared_ptr.hpp>

/**
 * There are lot of operations where we have to visit each individual element
 * of a distributed matrix. This visitor is a uniform means of achieving that.
 */ 
template <typename MatrixType,
          typename FunctorType>
struct matrix_visitor_t {
  /** 
   * Provide apply method
   * void apply(boost::shared_ptr<MatrixType>, FunctorType&);
   */ 
};

#if ALD_HAVE_ELEMENTAL==1

#include <El.hpp>

template <typename FunctorType>
struct matrix_visitor_t <El::DistMatrix<double>, FunctorType> {
  typedef El::DistMatrix<double> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;

  static void apply (MatrixPtrType A, 
                     FunctorType& functor) {
    const int64_t j_max = A->LocalWidth();
    const int64_t i_max = A->LocalHeight();
    const int64_t r_shift = A->RowShift();
    const int64_t r_stride = A->RowStride();
    const int64_t c_shift = A->ColShift();
    const int64_t c_stride = A->ColStride();
    for (int64_t j_lcl=0; j_lcl<j_max; ++j_lcl) {
      const int64_t j = r_shift + r_stride*j_lcl;
      for(int64_t i_lcl=0; i_lcl<i_max; ++i_lcl) {
        const int64_t i = c_shift + c_stride*i_lcl;
        functor.apply (A, i, j, i_lcl, j_lcl);
      }
    }
  }
};

#endif /** ALD_HAVE_ELEMENTAL */

#if ALD_HAVE_EIGEN==1

#include <Eigen/Dense>
#include <Eigen/Sparse>

template <typename FunctorType>
struct matrix_visitor_t <Eigen::Matrix<double,
                                       Eigen::Dynamic,
                                       Eigen::Dynamic>, 
                         FunctorType> {
  typedef Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;

  static void apply (MatrixPtrType A, 
                     FunctorType& functor) {
    const int64_t m = A->rows();
    const int64_t n = A->cols();
    #pragma omp parallel for
    for (int64_t j=0; j<n; ++j) 
      #pragma omp parallel for
      for (int64_t i=0; i<m; ++i) 
        functor.apply (A, i, j);
  }
};

template <typename FunctorType>
struct matrix_visitor_t <Eigen::Matrix<double,
                                       Eigen::Dynamic,
                                       1/*vector*/>, 
                         FunctorType> {
  typedef Eigen::Matrix<double, Eigen::Dynamic, 1> VectorType;
  typedef boost::shared_ptr<VectorType> VectorPtrType;

  static void apply (VectorPtrType x, 
                     FunctorType& functor) {
    const int64_t m = x->rows();
    #pragma omp parallel for
    for (int64_t i=0; i<m; ++i) functor.apply (x, i);
  }
};

#endif /** ALD_HAVE_EIGEN */

#endif /** ALD_MATRIX_VISITOR_HPP */
