#ifndef ALD_LOG_HPP
#define ALD_LOG_HPP

#include <iostream>

#include <boost/log/sources/global_logger_storage.hpp>
#include <boost/log/sources/severity_feature.hpp>
#include <boost/log/sources/severity_logger.hpp>
#include <boost/log/sources/record_ostream.hpp>
#include <boost/log/expressions.hpp>
#include <boost/log/trivial.hpp>

#include <ALD/config.h>
#if ALD_HAVE_ELEMENTAL==1
#include <mpi.h>
#endif

namespace blg = boost::log;

BOOST_LOG_GLOBAL_LOGGER(
  ALD_logger,
  boost::log::sources::severity_logger_mt<boost::log::trivial::severity_level>)

#define LOG_TRACE BOOST_LOG_SEV(ALD_logger::get(),boost::log::trivial::trace)
#define LOG_DEBUG BOOST_LOG_SEV(ALD_logger::get(),boost::log::trivial::debug)
#define LOG_INFO BOOST_LOG_SEV(ALD_logger::get(),boost::log::trivial::info)
#define LOG_WARNING BOOST_LOG_SEV(ALD_logger::get(),boost::log::trivial::warning)
#define LOG_ERROR BOOST_LOG_SEV(ALD_logger::get(),boost::log::trivial::error)
#define LOG_FATAL BOOST_LOG_SEV(ALD_logger::get(),boost::log::trivial::fatal)

struct LogLevel {
  enum severity { TRACE,
                  DEBUG,
                  INFO,
                  WARNING,
                  ERROR,
                  FATAL
                };
};

BOOST_LOG_GLOBAL_LOGGER_INIT(ALD_logger,
    blg::sources::severity_logger_mt<blg::trivial:severity_level>) {
  blg::core::get()->set_filter(blg::trivial::severity >= blg::trivial::error);
  return blg::sources::severity_logger_mt<blg::trivial::severity_level>();
}

static inline void setLogLevel(LogLevel::severity threshold) {
  namespace blg = boost::log;
  blg::trivial::severity_level bl_threshold;

  switch (threshold) {
    case LogLevel::TRACE:   bl_threshold = blg::trivial::trace; break;
    case LogLevel::DEBUG:   bl_threshold = blg::trivial::debug; break;
    case LogLevel::INFO:    bl_threshold = blg::trivial::info; break;
    case LogLevel::WARNING: bl_threshold = blg::trivial::warning; break;
    case LogLevel::ERROR:   bl_threshold = blg::trivial::error; break;
    case LogLevel::FATAL:   bl_threshold = blg::trivial::fatal; break;
  }

  blg::core::get()->set_filter(blg::trivial::severity > blg::trivial::trace);
  LOG_TRACE << "";
  blg::core::get()->set_filter(blg::trivial::severity >= bl_threshold);
}

static inline void setLogLevel(int threshold) {
#if ALD_HAVE_ELEMENTAL==1
    int mpi_rank;
    MPI_Comm_rank(MPI_COMM_WORLD, &mpi_rank);
    if (mpi_rank!=0) {
        setLogLevel(LogLevel::FATAL);
        return;
    }
#endif

    switch(threshold) {
      case 0 : setLogLevel(LogLevel::FATAL  ); break;
      case 1 : setLogLevel(LogLevel::ERROR  ); break;
      case 2 : setLogLevel(LogLevel::WARNING); break;
      case 3 : setLogLevel(LogLevel::INFO   ); break;
      case 4 : setLogLevel(LogLevel::DEBUG  ); break;
      default: setLogLevel(LogLevel::TRACE  ); break;
    }
}

#endif // ALD_LOG_HPP
