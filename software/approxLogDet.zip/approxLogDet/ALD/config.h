/** Do we have time.h */
#define ALD_HAVE_TIME_H 1

/** Do we have sys/time.h */
#define ALD_HAVE_SYS_TIME_H 1

/** Do we have sys/stat.h */
#define ALD_HAVE_SYS_STAT_H 1

/** Are we running Linux */
/* #undef ALD_LINUX */

/** Are we running Windows */
/* #undef ALD_WINDOWS */

/** Are we running Darwin */
#define ALD_DARWIN 1

/** Are we running AIX */
/* #undef ALD_AIX */

/** Are we using Elemental */
/* #undef ALD_HAVE_ELEMENTAL */

/** Are we using Eigen3 */
#define ALD_HAVE_EIGEN 1

/** Are we using MatrixMarket */
/* #undef ALD_HAVE_MATRIX_MARKET */
