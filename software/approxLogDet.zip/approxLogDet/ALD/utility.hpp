#ifndef ALD_UTILITY_HPP
#define ALD_UTILITY_HPP

#include <fstream>
#include <iostream>

/**
 * The one annoying problem is that OutputIterator's do not define
 * a value type, so it may not always work! Hrmp!
 */
static unsigned int generate_seed () {
  unsigned int r_int;
  ALD::timer_t duration;
  LOG_DEBUG << "Generating random seed";

  r_int = std::time(NULL);

  LOG_DEBUG << "DONE (" << r_int << ")" << " in " << duration.toc();
  return r_int;
}

#endif /** ALD_UTILITY_HPP */
