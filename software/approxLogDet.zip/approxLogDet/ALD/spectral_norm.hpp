#ifndef ALD_SPECTRAL_NORM_HPP
#define ALD_SPECTRAL_NORM_HPP


#include <vector>
#include <algorithm>
#include <ALD/config.h>
#include <boost/random.hpp>
#include <boost/random/threefry.hpp>
#include <boost/random/counter_based_engine.hpp>

#include "log.hpp"
#include "timer.hpp"
#include "utility.hpp"

/**
 * @brief Compute the approximate top eigen-value of matrix A.
 * @param[in] A Symmetrix positive definite matrix.
 * @return Approximate top eigen-value of A
 */
template <typename MatrixType>
struct spectral_norm_t {
  /**
   * Constructor:
   * spectral_norm_t (int64_t n, int64_t t);
   */

  /**
   * Reset the state
   * void reset ();
   */

  /**
   * Compute the approximate spectral norm.
   * double apply (boost::shared_ptr<MatrixType>);
   */

  /**
   * Compute the spectral norm.
   * double check (boost::shared_ptr<MatrixType>);
   */
};

#if ALD_HAVE_ELEMENTAL==1

#include <El.hpp>

/** Specialization for Elemental matrices */
template <>
struct spectral_norm_t<El::DistMatrix<double> > {
  typedef El::DistMatrix<double> MatrixType;
  typedef boost::shared_ptr<MatrixType> MatrixPtrType;
  typedef boost::random::threefry<4, uint32_t> Prf;
  typedef boost::random::counter_based_engine<uint32_t, Prf, 64> engine_type;
  typedef boost::uniform_01<double> uni_real_type;
  typedef boost::variate_generator<engine_type,
                                   uni_real_type> uni_real_prng_type;

  struct make_uniform_t {
    mutable uni_real_prng_type prng;

    make_uniform_t(int seed) : prng(engine_type(seed), uni_real_type()) {}

    double operator()(double in) const { return (prng()>0.5)?-1:1; }
  };

  int64_t n;
  int64_t t;
  MatrixPtrType x;
  MatrixPtrType x_shdw;

  /**
   * Constructor:
   * Initialize a matrix with A.
   */
  spectral_norm_t (int64_t n,
                   int64_t t,
                   int seed=-1) : n(n),
                                  t(t),
                                  x(new MatrixType(n,1)),
                                  x_shdw(new MatrixType(n,1)) {
    ALD::timer_t duration;
    LOG_DEBUG << "Creating x {-1,+1} ";

    if (0>seed) seed=generate_seed();
    El::EntrywiseMap(*x, std::function<double(double)>(make_uniform_t(seed)));
    El::Scale(1./El::Nrm2(*x), *x);

    LOG_DEBUG << "DONE in " << duration.toc();
  }

  double apply (MatrixPtrType A) {
    /** 2. Do a specified number of random iterations */
    ALD::timer_t duration;
    LOG_DEBUG << "Iteratively computing x_{i+1} = Ax_{i} ";
    for (int64_t i=0; i<t; ++i) {
      El::Hemv(El::UPPER, 1.0, *A, *x, 0.0, *x_shdw);
      x.swap(x_shdw);
      El::Scale(1./El::Nrm2(*x), *x);
    }
    LOG_DEBUG << "DONE in " << duration.toc();

    /** 3. Return the top eigen-value/spectral norm */
    /** No need to compute x_T_x because we have normalized it to 1 */
    duration.tic();
    LOG_DEBUG << "Computing x_T(A)x/(x_T_x) ";
    El::Hemv(El::UPPER, 1.0, *A, *x, 0.0, *x_shdw);
    double x_T_A_x = El::Dot(*x_shdw, *x);
    const double lambda_1 = x_T_A_x;
    LOG_DEBUG << "DONE in " << duration.toc();

    return lambda_1;
  }

  /**
   * Check against Elemental --- for some reason, there is no way to
   * just extract the top-Eigen value from Elemental :-/.
   */
  double check (MatrixPtrType A) {
    ALD::timer_t duration;
    LOG_DEBUG << "Copying A ";
    El::DistMatrix<double> H(*A);
    LOG_DEBUG << "DONE in " << duration.toc();

    duration.tic();
    LOG_DEBUG << "Computing spectral norm value accurately ";
    El::DistMatrix<double, El::VR, El::STAR> w;
    El::HermitianEig(El::UPPER, H, w, El::DESCENDING);
    LOG_DEBUG << "DONE in " << duration.toc();

    return w.Get(0,0);
  }
};

#endif /** ALD_HAVE_ELEMENTAL */

#if ALD_HAVE_EIGEN==1

#include <Eigen/Dense>
#include <Eigen/Sparse>

/** Specialization for Elemental matrices */
template <typename EigenMT>
struct eigen_spectral_norm_t {
  typedef EigenMT EigenMatrixType;
  typedef Eigen::Matrix<double, Eigen::Dynamic, 1> EigenVectorType;
  typedef boost::shared_ptr<EigenMatrixType> EigenMatrixPtrType;
  typedef boost::shared_ptr<EigenVectorType> EigenVectorPtrType;
  typedef boost::random::threefry<4, uint32_t> Prf;
  typedef boost::random::counter_based_engine<uint32_t, Prf, 64> engine_type;
  typedef boost::uniform_01<double> uni_real_type;
  typedef boost::variate_generator<engine_type,
                                   uni_real_type> uni_real_prng_type;

  int64_t n;
  int64_t t;
  EigenVectorType x;
  EigenVectorType x_shdw;

  /**
   * Constructor:
   * Initialize a matrix with A.
   */
  eigen_spectral_norm_t (int64_t n,
                         int64_t t,
                         int seed) :  n(n), t(t), x(n), x_shdw(n) {
    ALD::timer_t duration;
    LOG_DEBUG << "Creating x {-1,+1} ";

    if (0>seed) seed=generate_seed();
    uni_real_prng_type prng (engine_type(generate_seed()), (uni_real_type()));
    for(int64_t i=0;i<x.rows();++i) x[i] = (prng()>0.5) ? -1:1;
    const double x_norm = x.norm();
    x = x * (1.0/x_norm);

    LOG_DEBUG << "DONE in " << duration.toc();
  }

  double apply (EigenMatrixPtrType A) {
    /** 1. Pick a starting vector uniformly at random */
    ALD::timer_t duration;
    LOG_DEBUG << "Iteratively computing -x_{i+1} = Ax_{i} ";

    /** 2. Do a specified number of random iterations */
    for (int64_t i=0; i<t; ++i) {
      x = A->template selfadjointView<Eigen::Upper>() * x;
      const double x_norm = x.norm();
      x = x * (1.0/x_norm);
    }

    LOG_DEBUG << "DONE in " << duration.toc();
    duration.tic();
    LOG_DEBUG << "Computing x_T(A)x/(x_T_x) ";

    /** 3. Return the top eigen-value/spectral norm */
    /** No need to compute x_T_x because we have normalized it to 1 */
    x_shdw = A->template selfadjointView<Eigen::Upper>() * x;
    double x_T_A_x = x_shdw.dot(x);
    const double lambda_1 = x_T_A_x;
    LOG_DEBUG << "DONE in " << duration.toc();

    return lambda_1;
  }

  virtual double check (EigenMatrixPtrType A) = 0;
};

/** Specialization for dense Eigen matrices */
template <>
struct spectral_norm_t<Eigen::Matrix<double,
                                     Eigen::Dynamic,
                                     Eigen::Dynamic> > :
        public eigen_spectral_norm_t<Eigen::Matrix<double,
                                     Eigen::Dynamic,
                                     Eigen::Dynamic> > {
  typedef eigen_spectral_norm_t<Eigen::Matrix<double,
                                              Eigen::Dynamic,
                                              Eigen::Dynamic> > base_type;
  typedef base_type::EigenMatrixType MatrixType;
  typedef base_type::EigenMatrixPtrType MatrixPtrType;

  /**
   * Constructor:
   * Initialize a matrix with A.
   */
  spectral_norm_t (int64_t n,
                   int64_t t,
                   int seed=-1) : base_type(n, t, seed) {}

  /**
   * Check against the true value
   */
  virtual double check (MatrixPtrType A) {
    ALD::timer_t duration;
    LOG_DEBUG << "Copying A ";
    MatrixType H = (*A);
    LOG_DEBUG << "DONE in " << duration.toc();

    duration.tic();
    LOG_DEBUG << "Computing spectral norm value accurately ";
    Eigen::SelfAdjointEigenSolver<MatrixType> eigenSolver;
    eigenSolver.compute (H, Eigen::EigenvaluesOnly);
    LOG_DEBUG << "DONE in " << duration.toc();

    /** Everything is sorted in ascending order, so take the last one */
    return eigenSolver.eigenvalues()[H.rows()-1];
  }
};

/** Specialization for Eigen::SparseMatrix */
template <>
struct spectral_norm_t<Eigen::SparseMatrix<double> > :
        public eigen_spectral_norm_t<Eigen::SparseMatrix<double> > {
  typedef eigen_spectral_norm_t<Eigen::SparseMatrix<double> > base_type;
  typedef base_type::EigenMatrixType MatrixType;
  typedef base_type::EigenMatrixPtrType MatrixPtrType;

  /**
   * Constructor:
   * Initialize a matrix with A.
   */
  spectral_norm_t (int64_t n,
                   int64_t t,
                   int seed=-1) : base_type(n, t, seed) {}

  /**
   * Check against the true value
   */
  virtual double check (MatrixPtrType A) {
    ALD::timer_t duration;
    LOG_DEBUG << "Copying A ";
    MatrixType H = (*A);
    LOG_DEBUG << "DONE in " << duration.toc();

    duration.tic();
    LOG_DEBUG << "Computing spectral norm value accurately ";

    /** This is the Cholesky algorithm for computing the spectral norm */
    for (int64_t i=0; i<t; ++i) {
      Eigen::SimplicialLLT<MatrixType> cholesky_of_H(H);
      MatrixType L = cholesky_of_H.matrixL();
      H = cholesky_of_H.matrixU() * cholesky_of_H.matrixL();
    }

    std::vector<double> diag(H.diagonal().rows());
    for (int64_t i=0; i<H.diagonal().rows(); ++i) diag[i] = H.diagonal()[i];
    std::sort(diag.begin(), diag.end());

    LOG_DEBUG << "DONE in " << duration.toc();

    return diag[diag.size()-1];
  }
};

#endif /** ALD_HAVE_EIGEN */

#endif /** ALD_SPECTRAL_NORM_HPP */
